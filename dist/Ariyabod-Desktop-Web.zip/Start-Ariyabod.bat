@echo off
setlocal
cd /d "%~dp0"

set "PORT=8765"
set "URL=http://127.0.0.1:%PORT%/"

where powershell >nul 2>&1
if errorlevel 1 (
  echo PowerShell is required to start Ariyabod Desktop.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Ariyabod.ps1"
exit /b %ERRORLEVEL%
