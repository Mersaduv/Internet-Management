$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$webRoot = Join-Path $root 'web'
$port = 8765
$url = "http://127.0.0.1:$port/"

if (-not (Test-Path (Join-Path $webRoot 'index.html'))) {
  Write-Error "Web build not found. Run: flutter build web --release"
  exit 1
}

function Find-ChromePath {
  $candidates = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe",
    "$env:LocalAppData\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
  )

  foreach ($path in $candidates) {
    if (Test-Path $path) {
      return $path
    }
  }

  return $null
}

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add($url)
$listener.Start()

Write-Host "Ariyabod Desktop is running at $url"
Write-Host "Press Ctrl+C to stop."

$browser = Find-ChromePath
if ($browser) {
  Start-Process -FilePath $browser -ArgumentList @("--app=$url")
} else {
  Start-Process $url
}

try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response

    $relativePath = [Uri]::UnescapeDataString($request.Url.LocalPath.TrimStart('/'))
    if ([string]::IsNullOrWhiteSpace($relativePath)) {
      $relativePath = 'index.html'
    }

    $filePath = Join-Path $webRoot ($relativePath -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path $filePath) -or (Get-Item $filePath).PSIsContainer) {
      $filePath = Join-Path $webRoot 'index.html'
    }

    $bytes = [IO.File]::ReadAllBytes($filePath)
    $extension = [IO.Path]::GetExtension($filePath).ToLowerInvariant()
    $contentType = switch ($extension) {
      '.html' { 'text/html; charset=utf-8' }
      '.js' { 'application/javascript; charset=utf-8' }
      '.json' { 'application/json; charset=utf-8' }
      '.css' { 'text/css; charset=utf-8' }
      '.png' { 'image/png' }
      '.jpg' { 'image/jpeg' }
      '.jpeg' { 'image/jpeg' }
      '.gif' { 'image/gif' }
      '.svg' { 'image/svg+xml' }
      '.ico' { 'image/x-icon' }
      '.wasm' { 'application/wasm' }
      '.ttf' { 'font/ttf' }
      '.otf' { 'font/otf' }
      default { 'application/octet-stream' }
    }

    $response.ContentType = $contentType
    $response.ContentLength64 = $bytes.Length
    $response.OutputStream.Write($bytes, 0, $bytes.Length)
    $response.Close()
  }
}
finally {
  $listener.Stop()
  $listener.Close()
}
