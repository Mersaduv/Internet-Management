Ariyabod - نسخه دسکتاپ (Web Desktop)

این بسته بدون نیاز به Visual Studio ساخته شده است.

اجرا:
  1. روی Start-Ariyabod.bat دوبار کلیک کنید
  2. برنامه در پنجره Chrome/Edge (حالت app) باز می‌شود

مسیر خروجی:
  dist\desktop\web\

نکته:
  - برای خروجی exe بومی Windows، Flutter به Visual Studio (C++) نیاز دارد.
  - این نسخه همان اپلیکیشن است اما به‌صورت Web Desktop روی ویندوز اجرا می‌شود.
  - مدیریت MikroTik و اکثر قابلیت‌ها کار می‌کنند؛ WebView ممکن است محدودیت داشته باشد.

بازسازی:
  flutter build web --release
  سپس محتوای build\web را در dist\desktop\web کپی کنید.
